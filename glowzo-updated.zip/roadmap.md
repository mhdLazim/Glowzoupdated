# Homepage bottle sequence
- [x] Keep the bottle in a dedicated scroll-pinned section with reserved space above the usage guide.
- [x] Fade ingredients and usage in after arrival and out before departure using the bottle's scroll timing.
- [x] Verify the sequence and landing on phone and desktop and save changes.